"""Original illustrative bitmap textures; not scientific surface maps."""
from PIL import Image
import math, random
from pathlib import Path
root=Path(__file__).resolve().parent/'generated-demo-assets'
root.mkdir(exist_ok=True)
colors={'sun':(245,149,27),'mercury':(126,118,107),'venus_surface':(190,143,78),'mars':(177,81,46),'jupiter':(185,155,124),'saturn':(192,175,126),'uranus':(104,184,191),'neptune':(48,89,187),'ring':(172,155,119)}
for name,base in colors.items():
    rng=random.Random(name); w,h=512,256; image=Image.new('RGB',(w,h)); pixels=image.load()
    for y in range(h):
        for x in range(w):
            u=x/w*math.tau; v=y/h*math.pi
            noise=rng.uniform(-.06,.06)
            bands=.13*math.sin(v*35+math.sin(u*3)*.4)+.06*math.sin(v*82)
            stone=.12*math.sin(u*13+math.sin(v*17)*2)*math.sin(v*25)
            f=1+noise+(bands if name in ('jupiter','saturn','uranus','neptune') else stone)
            if name=='sun': f=1+noise+.18*math.sin(u*40+math.sin(v*60))*math.sin(v*45)
            if name=='ring': f=.8+.18*math.sin(x*.31)+.1*math.sin(x*.91); f*=.28 if .60<x/w<.66 else 1
            pixels[x,y]=tuple(max(0,min(255,int(c*f))) for c in base)
    image.save(root/f'{name}.jpg',quality=92)
print('Created 9 original illustrative bitmap textures.')
