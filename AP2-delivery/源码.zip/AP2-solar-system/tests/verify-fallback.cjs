const {chromium}=require('playwright'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{const browser=await chromium.launch({channel:'msedge',headless:true});try{
 const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{const original=WebGLRenderingContext.prototype.getExtension;WebGLRenderingContext.prototype.getExtension=function(name){return name==='OES_element_index_uint'?null:original.call(this,name);};});
 await page.goto('http://127.0.0.1:5174');await page.waitForFunction(()=>window.solar?.ready,null,{timeout:60000});
 const info=await page.evaluate(()=>solar.inspect());assert.equal(info.uintIndices,false);assert.equal(info.sphereTriangles,122880);assert.equal(info.glError,0);assert.deepEqual(errors,[]);
 const report={scenario:'OES_element_index_uint unavailable',sphereTriangles:info.sphereTriangles,glError:info.glError,errors,result:'PASS'};fs.writeFileSync(path.join(__dirname,'../evidence/fallback-verification.json'),JSON.stringify(report,null,2));console.log(report);
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
