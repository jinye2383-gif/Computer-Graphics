const {chromium}=require('playwright'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{const browser=await chromium.launch({channel:'msedge',headless:true});try{
const p=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];p.on('pageerror',e=>errors.push(e.message));
await p.goto('http://127.0.0.1:5174');await p.waitForFunction(()=>window.solar?.ready,null,{timeout:60000});
await p.evaluate(()=>{solar.preset({paused:true,tour:false,orbitTime:4,spinTime:1,orbits:false,axis:false});solar.setFocus('sun');});await p.waitForFunction(()=>!solar.inspect().textureUpgradePending);
const initial=await p.evaluate(()=>solar.inspect());assert.equal(initial.textureInfo.sun.gpu[0],4096);
const pixels=await p.evaluate(()=>{const c=document.querySelector('canvas'),g=c.getContext('webgl');solar.state.glow=0;solar.render();const a=new Uint8Array(c.width*c.height*4);g.readPixels(0,0,c.width,c.height,g.RGBA,g.UNSIGNED_BYTE,a);solar.state.glow=35;solar.render();const b=new Uint8Array(a.length);g.readPixels(0,0,c.width,c.height,g.RGBA,g.UNSIGNED_BYTE,b);let changed=0,white=0,maxDelta=0;for(let i=0;i<a.length;i+=4){const delta=Math.max(b[i]-a[i],b[i+1]-a[i+1],b[i+2]-a[i+2]);if(delta>2)changed++;maxDelta=Math.max(maxDelta,delta);if(b[i]>250&&b[i+1]>250&&b[i+2]>250)white++;}return {changedPixels:changed,whitePixels:white,maxDelta,pixelCount:a.length/4};});
assert.ok(pixels.changedPixels>1000);assert.ok(pixels.whitePixels/pixels.pixelCount<.001);assert.ok(pixels.maxDelta<100);
await p.screenshot({path:path.join(__dirname,'../evidence/soft-sun.png')});
await p.locator('#glow').fill('0');assert.equal(await p.evaluate(()=>solar.state.glow),0);await p.locator('#glow').fill('35');assert.equal(await p.evaluate(()=>solar.state.glow),35);
await p.evaluate(()=>solar.setProjection('orthographic'));await p.screenshot({path:path.join(__dirname,'../evidence/soft-sun-ortho.png')});
await p.evaluate(()=>{solar.setFocus('jupiter');solar.setFocus('mercury');});await p.waitForFunction(()=>!solar.inspect().textureUpgradePending);const closeup=await p.evaluate(()=>solar.inspect().closeTexture);assert.equal(closeup.id,'mercury');assert.equal(closeup.size[0],8192);
await p.locator('#reset').click();assert.equal(await p.evaluate(()=>solar.state.glow),35);assert.equal(await p.evaluate(()=>solar.inspect().closeTexture),null);assert.deepEqual(errors,[]);assert.equal(await p.evaluate(()=>solar.inspect().glError),0);
fs.writeFileSync(path.join(__dirname,'../evidence/glow-verification.json'),JSON.stringify({result:'PASS',defaultGlow:35,pixels,closeTexture:closeup,checks:['native 8K Mercury upload','visible bounded corona','slider','orthographic glow','rapid focus switch','reset releases close-up texture'],errors},null,2));console.log('Glow and native-resolution checks passed.');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
