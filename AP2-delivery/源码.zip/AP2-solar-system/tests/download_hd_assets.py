"""Download unmodified Solar System Scope texture files from a public mirror."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import urllib.request,json,hashlib
root=Path(__file__).resolve().parents[1]
mapping={'sun':'8k_sun.jpg','moon':'2k_moon.jpg','mercury':'8k_mercury.jpg','venus_surface':'4k_venus_atmosphere.jpg','earth_daymap':'8k_earth_daymap.jpg','earth_night':'8k_earth_nightmap.jpg','clouds':'2k_earth_clouds.jpg','mars':'8k_mars.jpg','jupiter':'8k_jupiter.jpg','saturn':'8k_saturn.jpg','uranus':'2k_uranus.jpg','neptune':'2k_neptune.jpg','ring':'8k_saturn_ring_alpha.png'}
def fetch(item):
    name,source=item
    url=('https://raw.githubusercontent.com/rajpatel5/Solar-System/master/' if name=='sun' else 'https://raw.githubusercontent.com/Shriisoot/Planets-texture/main/')+source
    data=urllib.request.urlopen(url,timeout=120).read()
    out=root/'dist'/'assets'/(name+Path(source).suffix)
    out.write_bytes(data)
    print(name,len(data),flush=True)
    return {'file':out.relative_to(root).as_posix(),'source':url,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with ThreadPoolExecutor(max_workers=4) as pool:
    records=list(pool.map(fetch,mapping.items()))
(root/'evidence'/'hd-assets.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
